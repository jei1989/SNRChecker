package kr.blogspot.smcity5.serialconsole;

import java.io.FileWriter;
import java.text.SimpleDateFormat;
import java.util.Calendar;

/**
 * Created by Administrator on 2017-08-21.
 */

public class LogWriter {

    public static String logdir = "mobilesatellite";
    public static String fullpath;
    public static String final_fullpath;

    public static void logWrite(String message, String title) {

        Calendar cal = Calendar.getInstance();
        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

        SimpleDateFormat dfname = new SimpleDateFormat("yyyy-MM-dd");
        /*************/
        FileWriter fos = null;
        try {
            fos = new FileWriter(fullpath + "//" + String.valueOf(dfname.format(cal.getTime())) + "_" + title + ".csv", true);
            final_fullpath = fullpath + "//" + String.valueOf(dfname.format(cal.getTime())) + "_" + title + ".csv";
            fos.write(String.valueOf(dfname.format(cal.getTime())) + "," + message + "\r\n");
            fos.close();
            /*************/
        } catch (Exception ex) {

        }
    }
}
