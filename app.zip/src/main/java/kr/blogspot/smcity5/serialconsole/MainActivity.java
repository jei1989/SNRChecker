package kr.blogspot.smcity5.serialconsole;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.hardware.usb.UsbManager;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;

import static java.lang.Double.parseDouble;
import static kr.blogspot.smcity5.serialconsole.R.id.listview;

@SuppressLint("InlinedApi")
public class MainActivity extends Activity {

    private FTDriver mSerial;
    private UsbReceiver mUsbReceiver;

    private static final String ACTION_USB_PERMISSION = "kr.co.andante.mobiledgs.USB_PERMISSION";

    private Boolean SHOW_DEBUG = false;
    private String TAG = "MainActivity";

    private int mBaudrate;

    private EditText	etWrite;

    private EditText	etLog;
    private ListView listView;
    private ListView listViewTitle;
    private EditText avgText;
    private EditText editText2;
    private EditText editText3;
    private LinearLayout nglinearLayout;
    private int colorindex = 0;
    private FrameLayout[] framelayout = new FrameLayout[20];
    Drawable draw;
    TextView textCurr;
    TextView path;
    String logmessage;
    TextView txtVersionName;

    private RingSoundPlay ringSoundPlay;
    private FailSoundPlay failSoundPlay;
    private int ringplay = 0;

    private Button	btnplay;
    private Button	btnstop;



    static final ArrayList<HashMap<String,String>> list = new ArrayList<HashMap<String,String>>();
    HashMap<String,String> temp00 = new HashMap<String,String>();
    HashMap<String,String> temp02 = new HashMap<String,String>();
    HashMap<String,String> temp04 = new HashMap<String,String>();
    HashMap<String,String> temp06 = new HashMap<String,String>();
    HashMap<String,String> temp08 = new HashMap<String,String>();
    HashMap<String,String> temp10 = new HashMap<String,String>();
    HashMap<String,String> temp12 = new HashMap<String,String>();
    SimpleAdapter adapter;
    SimpleAdapter adapterTitle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        setContentView(R.layout.activity_main);
        //setContentView(R.layout.mlistview);
        listView = (ListView)findViewById(listview);
        //listViewTitle = (ListView)findViewById(R.id.listviewtitle);
        avgText = (EditText)findViewById(R.id.avgText);
        editText2 = (EditText)findViewById(R.id.editText2);
        editText3 = (EditText)findViewById(R.id.editText3);
        //etWrite = (EditText)findViewById(R.id.strInput);
        nglinearLayout = (LinearLayout)findViewById(R.id.nglinearlayout);
        //nglinearLayout.setBackgroundColor(Color.RED );
        //linearLayout1.setBackground(R.drawable.background);
        textCurr = (TextView)findViewById(R.id.textView7);
        path = (TextView)findViewById(R.id.textView8);

        btnplay = (Button)findViewById(R.id.btnplay);
        btnstop = (Button)findViewById(R.id.btnstop);

        File mfile = new File((Environment.getExternalStorageDirectory().getAbsolutePath() + "//"+ LogWriter.logdir));
        if( !mfile.exists() )
        {
            mfile.mkdir();
        }
        LogWriter.fullpath = mfile.getAbsolutePath().toString();
        path.setText(  LogWriter.fullpath );

        /**************/
        framelayout[0] = (FrameLayout)findViewById(R.id.framelayout01);
        framelayout[1] = (FrameLayout)findViewById(R.id.framelayout02);
        framelayout[2] = (FrameLayout)findViewById(R.id.framelayout03);
        framelayout[3] = (FrameLayout)findViewById(R.id.framelayout04);
        framelayout[4] = (FrameLayout)findViewById(R.id.framelayout05);
        framelayout[5] = (FrameLayout)findViewById(R.id.framelayout06);
        framelayout[6] = (FrameLayout)findViewById(R.id.framelayout07);
        framelayout[7] = (FrameLayout)findViewById(R.id.framelayout08);
        framelayout[8] = (FrameLayout)findViewById(R.id.framelayout09);
        framelayout[9] = (FrameLayout)findViewById(R.id.framelayout10);
        framelayout[10] = (FrameLayout)findViewById(R.id.framelayout11);
        framelayout[11] = (FrameLayout)findViewById(R.id.framelayout12);
        framelayout[12] = (FrameLayout)findViewById(R.id.framelayout13);
        framelayout[13] = (FrameLayout)findViewById(R.id.framelayout14);
        framelayout[14] = (FrameLayout)findViewById(R.id.framelayout15);
        framelayout[15] = (FrameLayout)findViewById(R.id.framelayout16);
        framelayout[16] = (FrameLayout)findViewById(R.id.framelayout17);
        framelayout[17] = (FrameLayout)findViewById(R.id.framelayout18);
        framelayout[18] = (FrameLayout)findViewById(R.id.framelayout19);
        framelayout[19] = (FrameLayout)findViewById(R.id.framelayout20);
        //draw = framelayout[0].getBackground();
         /**************/
         for( int i=0;i<framelayout.length;i++)
         {
             framelayout[i].setBackgroundColor(Color.DKGRAY);
         }

        etLog = (EditText)findViewById(R.id.strLog);
        etLog.setTextColor(Color.WHITE);
        etLog.setFocusable(false);
        etLog.setClickable(false);

        mSerial = new FTDriver((UsbManager) getSystemService(Context.USB_SERVICE));

        // listen for new devices
        mUsbReceiver = new UsbReceiver(this, mSerial);

        IntentFilter filter = new IntentFilter();
        filter.addAction (UsbManager.ACTION_USB_DEVICE_ATTACHED);
        filter.addAction (UsbManager.ACTION_USB_DEVICE_DETACHED);
        registerReceiver (mUsbReceiver, filter);

        // load default baud rate
        mBaudrate = mUsbReceiver.loadDefaultBaudrate();

        // for requesting permission
        // setPermissionIntent() before begin()
        PendingIntent permissionIntent = PendingIntent.getBroadcast(this, 0, new Intent(ACTION_USB_PERMISSION), 0);
        mSerial.setPermissionIntent(permissionIntent);

        if (SHOW_DEBUG) {
            Log.d(TAG, "FTDriver beginning");
        }

        etLog.setTextSize(mUsbReceiver.GetTextFontSize());

        if (mSerial.begin(mBaudrate)) {
            if (SHOW_DEBUG) {
                Log.d(TAG, "FTDriver began");
            }
            mUsbReceiver.loadDefaultSettingValues();
            mUsbReceiver.mainloop();
        } else {
            if (SHOW_DEBUG) {
                Log.d(TAG, "FTDriver no connection");
            }
            Toast.makeText(this, "no connection", Toast.LENGTH_SHORT).show();
        }

        //btWrite = (Button)findViewById(R.id.btnWrite);
        //btWrite.setOnClickListener(new View.OnClickListener() {
        //    @Override
        //    public void onClick(View v) {
        //        mUsbReceiver.writeDataToSerial(etWrite.getText().toString());
        //    }
        //});

        btnplay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ringSoundPlay.soundStart();
            }
        });

        btnstop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                failSoundPlay.soundStart();
            }
        });


        adapter = new SimpleAdapter(
                this,
                list,
                R.layout.mlistview,
                new String[] {"tp","snr","curr","freq"},
                new int[] {R.id.text1,R.id.text2,R.id.text3,R.id.text4}

        );

        addListView();

        listView.setAdapter(adapter);

        /**************
        adapterTitle = new SimpleAdapter(
                this,
                list,
                R.layout.mlistview,
                new String[] {"tp","snr","freq","symbol"},
                new int[] {R.id.text11,R.id.text12,R.id.text13,R.id.text14}

        );

        addListViewTitle();

        listViewTitle.setAdapter(adapterTitle);
         /**************/

        try {
            String versionName = getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
            String appInfo = String.valueOf(getPackageManager().getPackageInfo(getPackageName(),0).packageName);
            txtVersionName = (TextView)findViewById(R.id.txtVersionName);
            txtVersionName.setText(appInfo + " , " + versionName);

        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }

        ringSoundPlay = new RingSoundPlay(this);
        failSoundPlay = new FailSoundPlay(this);

    }

    @Override
    public void onDestroy() {
        mUsbReceiver.closeUsbSerial();
        unregisterReceiver(mUsbReceiver);
        super.onDestroy();
    }

    public void onSetText(String buf)
    {
        try {
            //String temp = buf+"\n";

            SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
            java.util.Calendar c = java.util.Calendar.getInstance();
            String today2 = df.format(c.getTime());

            //etLog.append("["+ today2 +"] " +buf);
            String text = etLog.getText().toString();

            etLog.setText("[" + today2 + "] " + buf + text);

            text = etLog.getText().toString();
            if (text.length() > 800) {
                etLog.setText(text.substring(0, 800));
            }
            this.setTPinfo(buf);
        }catch(Exception ex)
        {

        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        /**********
        switch(item.getItemId())
        {
            case R.id.action_open:
                mUsbReceiver.openUsbSerial();
                break;
            case R.id.action_close:
                mUsbReceiver.closeUsbSerial();
                break;
        }
         /**********/
        return super.onOptionsItemSelected(item);
    }

    private void listViewItemBackground(int row)
    {
        try {
            listView.getChildAt(row).setBackgroundColor(Color.rgb(80, 100, 110));
        }catch(Exception ex)
        {

        }
    }

    private void listViewItemBackgroundDefault()
    {
        try {
            listView.getChildAt(0).setBackgroundColor(Color.rgb(65, 82, 97));
            listView.getChildAt(1).setBackgroundColor(Color.rgb(65, 82, 97));
            listView.getChildAt(2).setBackgroundColor(Color.rgb(65, 82, 97));
            listView.getChildAt(3).setBackgroundColor(Color.rgb(65, 82, 97));
            listView.getChildAt(4).setBackgroundColor(Color.rgb(65, 82, 97));
            listView.getChildAt(5).setBackgroundColor(Color.rgb(65, 82, 97));
        }catch(Exception ex){

        }
    }

    private void setSNRBackground(Double snr)
    {
        try {
            for (int i = 0; i < framelayout.length; i++) {
                framelayout[i].setBackgroundColor(Color.DKGRAY);
            }

            for (int i = 0; i < snr.intValue(); i++) {
                if (i < 20) {
                    framelayout[i].setBackgroundColor(Color.YELLOW);
                }
            }
        }catch(Exception ex)
        {

        }

    }

    private void setTPinfo(String minfo)
    {
        try {
            DecimalFormat format = new DecimalFormat(".##");
            String[] sinfo = minfo.split("\\ ");

            if( sinfo[0].toString().substring(0,2).equals("BS") ) {

                if (sinfo.length > 3) {
                    if (sinfo[0].equals("BS02")) {
                        temp02.put("tp", sinfo[0]);
                        if (parseDouble(temp02.get("snr").toString()) < parseDouble(sinfo[2])) {
                            temp02.put("snr", String.format("%.2f", parseDouble(sinfo[2])));
                        }
                        temp02.put("curr", String.format("%.2f", parseDouble(sinfo[2])));
                        temp02.put("freq", "997 Mhz");
                        listViewItemBackgroundDefault();
                        listViewItemBackground(0);
                        adapter.notifyDataSetChanged();

                        logmessage = sinfo[0] + "," + temp02.get("snr").toString() + "," + String.format("%.2f", parseDouble(sinfo[2]));

                    } else if (sinfo[0].equals("BS04")) {
                        temp04.put("tp", sinfo[0]);
                        if (parseDouble(temp04.get("snr").toString()) < parseDouble(sinfo[2])) {
                            temp04.put("snr", String.format("%.2f", parseDouble(sinfo[2])));
                        }
                        temp04.put("curr", String.format("%.2f", parseDouble(sinfo[2])));
                        temp04.put("freq", "1035 Mhz");
                        listViewItemBackgroundDefault();
                        listViewItemBackground(1);

                        adapter.notifyDataSetChanged();

                        logmessage = sinfo[0] + "," + temp04.get("snr").toString() + "," + String.format("%.2f", parseDouble(sinfo[2]));

                    } else if (sinfo[0].equals("BS06")) {
                        temp06.put("tp", sinfo[0]);
                        if (parseDouble(temp06.get("snr").toString()) < parseDouble(sinfo[2])) {
                            temp06.put("snr", String.format("%.2f", parseDouble(sinfo[2])));
                        }
                        temp06.put("curr", String.format("%.2f", parseDouble(sinfo[2])));
                        temp06.put("freq", "1085 Mhz");
                        listViewItemBackgroundDefault();
                        listViewItemBackground(2);

                        adapter.notifyDataSetChanged();

                        logmessage = sinfo[0] + "," + temp06.get("snr").toString() + "," + String.format("%.2f", parseDouble(sinfo[2]));

                    } else if (sinfo[0].equals("BS08")) {
                        temp08.put("tp", sinfo[0]);
                        if (parseDouble(temp08.get("snr").toString()) < parseDouble(sinfo[2])) {
                            temp08.put("snr", String.format("%.2f", parseDouble(sinfo[2])));
                        }
                        temp08.put("curr", String.format("%.2f", parseDouble(sinfo[2])));
                        temp08.put("freq", "1111 Mhz");
                        listViewItemBackgroundDefault();
                        listViewItemBackground(3);

                        adapter.notifyDataSetChanged();

                        logmessage = sinfo[0] + "," + temp08.get("snr").toString() + "," + String.format("%.2f", parseDouble(sinfo[2]));

                    } else if (sinfo[0].equals("BS10")) {
                        temp10.put("tp", sinfo[0]);
                        if (parseDouble(temp10.get("snr").toString()) < parseDouble(sinfo[2])) {
                            temp10.put("snr", String.format("%.2f", parseDouble(sinfo[2])));
                        }
                        temp10.put("curr", String.format("%.2f", parseDouble(sinfo[2])));
                        temp10.put("freq", "1150 Mhz");
                        listViewItemBackgroundDefault();
                        listViewItemBackground(4);

                        adapter.notifyDataSetChanged();

                        logmessage = sinfo[0] + "," + temp10.get("snr").toString() + "," + String.format("%.2f", parseDouble(sinfo[2]));

                    } else if (sinfo[0].equals("BS12")) {
                        temp12.put("tp", sinfo[0]);
                        if (parseDouble(temp12.get("snr").toString()) < parseDouble(sinfo[2])) {
                            temp12.put("snr", String.format("%.2f", parseDouble(sinfo[2])));
                        }
                        temp12.put("curr", String.format("%.2f", parseDouble(sinfo[2])));
                        temp12.put("freq", "1188 Mhz");
                        listViewItemBackgroundDefault();
                        listViewItemBackground(5);

                        adapter.notifyDataSetChanged();

                        logmessage = sinfo[0] + "," + temp12.get("snr").toString() + "," + String.format("%.2f", parseDouble(sinfo[2]));

                    }

/************/
                    Double dbl = (parseDouble(temp02.get("snr").toString())
                            + parseDouble(temp04.get("snr").toString())
                            + parseDouble(temp06.get("snr").toString())
                            + parseDouble(temp08.get("snr").toString())
                            + parseDouble(temp10.get("snr").toString())
                            + parseDouble(temp12.get("snr").toString())) / 6;
/************/
                    if (dbl < 15) {
                        avgText.setTextColor(Color.RED);
                        avgText.setText("FAIL ");
                        //nglinearLayout.setBackgroundColor(Color.RED );
                        editText2.setText(String.format("%.2f", dbl) + " dB");

                        ringplay = 0;

                        Calendar cal = Calendar.getInstance();
                        if ( cal.get( Calendar.SECOND ) % 10 == 0 ) {
                            failSoundPlay.soundStart();
                        }




                    } else {
                        avgText.setTextColor(Color.CYAN);
                        avgText.setText("PASS ");
                        //nglinearLayout.setBackgroundColor(Color.BLUE);
                        editText2.setText(String.format("%.2f", dbl) + " dB");

                        if( ringplay == 0 )
                        {
                            ringplay = 1;
                            ringSoundPlay.soundStart();
                        }

                    }

                    if (sinfo != null && sinfo[2] != null && !sinfo[2].equals("")) {

                        setSNRBackground(Double.parseDouble(sinfo[2]));
                        textCurr.setText(String.format("%.2f", parseDouble(sinfo[2])));
                        logmessage = logmessage + "," + String.format("%.2f", dbl);
                        LogWriter.logWrite( logmessage , editText3.getText().toString());
                        path.setText(  LogWriter.final_fullpath );

                    }

                }
            }
        }catch(Exception ex)
        {

        }
    }

    private void addListView() {

        try {
            if (list != null) {
                list.clear();
            }

            temp02.put("tp", "BS02");
            temp02.put("snr", "0.0");
            temp02.put("curr", "0.0");
            temp02.put("freq", "997 MHz");
            list.add(temp02);

            temp04.put("tp", "BS04");
            temp04.put("snr", "0.0");
            temp04.put("curr", "0.0");
            temp04.put("freq", "1035 MHz");
            list.add(temp04);

            temp06.put("tp", "BS06");
            temp06.put("snr", "0.0");
            temp06.put("curr", "0.0");
            temp06.put("freq", "1085 MHz");
            list.add(temp06);

            temp08.put("tp", "BS08");
            temp08.put("snr", "0.0");
            temp08.put("curr", "0.0");
            temp08.put("freq", "1111 MHz");
            list.add(temp08);

            temp10.put("tp", "BS10");
            temp10.put("snr", "0.0");
            temp10.put("curr", "0.0");
            temp10.put("freq", "1150 MHz");
            list.add(temp10);

            temp12.put("tp", "BS12");
            temp12.put("snr", "0.0");
            temp12.put("curr", "0.0");
            temp12.put("freq", "1188 MHz");
            list.add(temp12);
        }catch(Exception ex)
        {

        }
    }

}
