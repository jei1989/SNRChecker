package kr.blogspot.smcity5.serialconsole;

import android.content.Context;
import android.media.MediaPlayer;

/**
 * Created by Administrator on 2017-08-22.
 */

public class RingSoundPlay implements Runnable{

    MediaPlayer player;
    Thread thr;
    MainActivity mainActivity;
    public RingSoundPlay(MainActivity mainActivity)
    {
        this.mainActivity = mainActivity;
    }

    public void soundStart()
    {
        thr = new Thread(this);
        thr.start();
    }

    public void run()
    {
        soundPlay();
    }

    private void soundPlay()
    {
        Context c = this.mainActivity.getApplicationContext();
        try {

            try {
                if(player != null)
                {
                    player.stop();
                    player.release();
                    player = null;
                }

            } catch (IllegalStateException e) {
                //e.printStackTrace();
            }
            player = MediaPlayer.create(c, R.raw.ring);
            player.setLooping(false);
            player.start();
        }catch (IllegalStateException e) {
            //e.printStackTrace();
        }

        /*****************
        Uri notification = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
        Ringtone r = RingtoneManager.getRingtone(this.mainActivity.getApplicationContext(), notification);
        r.play();
         /*************/
    }
}
